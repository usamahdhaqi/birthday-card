Letakkan foto kenangan di folder ini: photo1.jpg, photo2.jpg, photo3.jpg, photo4.jpg.
Jika nama/path berbeda, sesuaikan CONFIG.photos pada script.js.
