Letakkan file musik milik Anda di sini dengan nama birthday-music.mp3.
Atau ubah CONFIG.audioFile pada script.js.
